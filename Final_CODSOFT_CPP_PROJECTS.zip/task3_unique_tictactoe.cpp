#include <iostream>
using namespace std;

char grid[3][3];
int currentPlayer = 0;

void initializeBoard() {
    char c = '1';
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            grid[i][j] = c++;
}

void displayBoard() {
    cout << "\nCurrent Board:\n";
    for (int i = 0; i < 3; i++) {
        cout << " ";
        for (int j = 0; j < 3; j++) {
            cout << grid[i][j];
            if (j < 2) cout << " | ";
        }
        cout << "\n";
        if (i < 2) cout << "---|---|---\n";
    }
    cout << endl;
}

bool markPosition(int pos, char symbol) {
    int row = (pos - 1) / 3;
    int col = (pos - 1) % 3;
    if (grid[row][col] != 'X' && grid[row][col] != 'O') {
        grid[row][col] = symbol;
        return true;
    }
    return false;
}

bool checkWinner() {
    for (int i = 0; i < 3; i++) {
        if (grid[i][0] == grid[i][1] && grid[i][1] == grid[i][2]) return true;
        if (grid[0][i] == grid[1][i] && grid[1][i] == grid[2][i]) return true;
    }
    if (grid[0][0] == grid[1][1] && grid[1][1] == grid[2][2]) return true;
    if (grid[0][2] == grid[1][1] && grid[1][1] == grid[2][0]) return true;
    return false;
}

int main() {
    initializeBoard();
    char symbol;
    int move;

    for (int turn = 0; turn < 9; ++turn) {
        symbol = (turn % 2 == 0) ? 'X' : 'O';
        displayBoard();
        cout << "Player " << symbol << ", choose your position (1-9): ";
        cin >> move;

        if (!markPosition(move, symbol)) {
            cout << "Invalid move. Try again." << endl;
            turn--;
            continue;
        }

        if (checkWinner()) {
            displayBoard();
            cout << "Congratulations! Player " << symbol << " wins!" << endl;
            return 0;
        }
    }

    displayBoard();
    cout << "It's a draw!" << endl;
    return 0;
}
