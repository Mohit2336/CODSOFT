#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main() {
    srand(static_cast<unsigned int>(time(0)));
    int target = rand() % 100 + 1;
    int userGuess = 0;

    cout << "Welcome to the Number Guessing Game!" << endl;
    cout << "Guess a number between 1 and 100." << endl;

    while (userGuess != target) {
        cout << "Enter your guess: ";
        cin >> userGuess;

        if (userGuess < target) {
            cout << "Oops! That's too low. Try again!" << endl;
        } else if (userGuess > target) {
            cout << "Oops! That's too high. Try again!" << endl;
        } else {
            cout << "Bravo! You've guessed the correct number: " << target << endl;
        }
    }

    return 0;
}
