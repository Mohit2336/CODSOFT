#include <iostream>
using namespace std;

int main() {
    double val1, val2, result;
    char operation;

    cout << "Simple Calculator Program" << endl;
    cout << "Enter first number: ";
    cin >> val1;
    cout << "Choose operation (+ - * /): ";
    cin >> operation;
    cout << "Enter second number: ";
    cin >> val2;

    switch(operation) {
        case '+':
            result = val1 + val2;
            break;
        case '-':
            result = val1 - val2;
            break;
        case '*':
            result = val1 * val2;
            break;
        case '/':
            if (val2 == 0) {
                cout << "Error: Cannot divide by zero." << endl;
                return 1;
            }
            result = val1 / val2;
            break;
        default:
            cout << "Invalid operation selected!" << endl;
            return 1;
    }

    cout << "Result: " << result << endl;
    return 0;
}
